import '../models/campaign.dart';

final List<Campaign> dummyCampaigns = [
  Campaign(
    title: 'Bantu Renovasi Masjid',
    description: 'Menggalang dana untuk renovasi masjid yang rusak akibat banjir.',
    imageUrl: 'https://th.bing.com/th/id/OIP.hQb8WI8v7GR15oNHqfPIWQHaDt',
    targetAmount: 10000000,
    collectedAmount: 2500000,
    type: 'financial',
    creatorName: 'Ust. Rahmat',
  ),
  Campaign(
    title: 'Donasi Baju Layak Pakai',
    description: 'Kumpulkan pakaian bekas layak pakai untuk korban bencana.',
    imageUrl: 'https://th.bing.com/th/id/OIP.2RJQha5SKrscAYivqVst2AHaEl',
    targetAmount: 1000,
    collectedAmount: 600,
    type: 'barang',
    creatorName: 'Komunitas Pemuda',
  ),
  Campaign(
    title: 'Dukungan Emosional untuk Anak Panti',
    description: 'Berikan semangat dan pesan positif untuk anak-anak panti asuhan.',
    imageUrl: 'https://th.bing.com/th/id/OIP.2RJQha5SKrscAYivqVst2AHaEl',
    targetAmount: 500,
    collectedAmount: 200,
    type: 'emosional',
    creatorName: 'Psikolog Muda Indonesia',
  ),
];
