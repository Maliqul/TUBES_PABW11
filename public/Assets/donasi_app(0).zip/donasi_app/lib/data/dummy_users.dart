import '../models/user_model.dart';

List<UserModel> dummyUsers = [
  UserModel(
    id: 1,
    name: 'Admin',
    email: 'admin@gmail.com',
    password: 'password',
    phone: '081111222333',
    role: 'admin',
  ),
  UserModel(
    id: 2,
    name: 'User1',
    email: 'user1@gmail.com',
    password: 'password',
    phone: '086111222333',
    role: 'user',
  ),
  UserModel(
    id: 3,
    name: 'User2',
    email: 'user2@gmail.com',
    password: 'password',
    phone: '087111222333',
    role: 'user',
  ),
];
