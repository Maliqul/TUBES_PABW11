import '../models/identity_verification_model.dart';

List<IdentityVerificationModel> identityVerifications = [];
