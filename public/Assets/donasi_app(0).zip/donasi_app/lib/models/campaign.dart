class Campaign {
  final String title;
  final String description;
  final String imageUrl;
  final int targetAmount;
  final int collectedAmount;
  final String type; 
  final String creatorName;

  Campaign({
    required this.title,
    required this.description,
    required this.imageUrl,
    required this.targetAmount,
    required this.collectedAmount,
    required this.type,
    required this.creatorName,
  });

  double get progress => collectedAmount / targetAmount;
}
