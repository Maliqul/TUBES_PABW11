import 'dart:io';

import 'package:donasi_app/pages/auth/login_page.dart';
import 'package:donasi_app/pages/edit_profile_page.dart';
import 'package:donasi_app/pages/verifikasi_identitas_page.dart';
import 'package:flutter/material.dart';
import '../data/dummy_users.dart';
import '../models/user_model.dart';
import 'verifikasi_identitas_admin_page.dart';

class ProfilePage extends StatefulWidget {
  final UserModel user;
  const ProfilePage({super.key, required this.user});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    final index = dummyUsers.indexWhere((u) => u.id == widget.user.id);
    return Scaffold(
      backgroundColor: Colors.amber[700],
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 60),
          ClipOval(
            child: dummyUsers[index].photo != null
                ? Image.file(
                    File(dummyUsers[index].photo!),
                    width: 80,
                    height: 80,
                    fit: BoxFit.cover,
                  )
                : Image.asset(
                    'assets/images/img_profile.webp',
                    width: 80,
                  ),
          ),
          const SizedBox(height: 8),
          Text(
            dummyUsers[index].name,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            dummyUsers[index].email,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 24),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(24),
                      topRight: Radius.circular(24))),
              child: Column(
                children: [
                  _buildMenuItem(
                    icon: Icons.account_circle,
                    title: 'Edit Profile',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => EditProfilePage(
                            user: dummyUsers[index],
                          ),
                        ),
                      ).then((_) => setState(() {}));
                    },
                  ),
                  _buildMenuItem(
                    icon: Icons.badge_outlined,
                    title: 'Verifikasi Identitas',
                    onTap: () {
                      if (widget.user.role == 'admin') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                const VerifikasiIdentitasAdminPage(),
                          ),
                        );
                      } else {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => VerifikasiIdentitasPage(
                              user: dummyUsers[index],
                            ),
                          ),
                        );
                      }
                    },
                  ),
                  _buildMenuItem(
                    icon: Icons.logout,
                    title: 'Keluar',
                    onTap: () {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginPage()),
                        (Route<dynamic> route) => false,
                      );
                    },
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        color: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(16)),
              child: Icon(
                icon,
                color: Colors.amber[700],
              ),
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w500,
              ),
            ),
            const Spacer(),
            const Icon(Icons.arrow_forward_ios)
          ],
        ),
      ),
    );
  }
}
