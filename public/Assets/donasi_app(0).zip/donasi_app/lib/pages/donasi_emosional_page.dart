import 'package:flutter/material.dart';

class DonasiEmosionalPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Donasi Barang")),
      body: Center(child: Text("Halaman Donasi Barang")),
    );
  }
}
