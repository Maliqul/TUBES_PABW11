import 'package:flutter/material.dart';

class RiwayatPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Riwayat Donasi")),
      body: Center(child: Text("Halaman Riwayat Donasi")),
    );
  }
}
