import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart' as carousel;

import '../data/dummy_campaigns.dart';
import '../widgets/campaign_card.dart';
import 'donasi_uang_page.dart';
import 'donasi_barang_page.dart';
import 'riwayat_page.dart';
import 'campaign_detail_page.dart';

class HomePage extends StatelessWidget {
  final List<String> carouselImages = [
    'https://th.bing.com/th/id/OIP.2RJQha5SKrscAYivqVst2AHaEl',
    'https://th.bing.com/th/id/OIP.2RJQha5SKrscAYivqVst2AHaEl',
    'https://th.bing.com/th/id/OIP.hQb8WI8v7GR15oNHqfPIWQHaDt',
  ];

  final List<Map<String, dynamic>> menuItems = [
    {'icon': Icons.volunteer_activism, 'label': 'Donasi Uang'},
    {'icon': Icons.shopping_bag, 'label': 'Donasi Barang'},
    {'icon': Icons.history, 'label': 'Riwayat'},
    {'icon': Icons.favorite, 'label': 'Favorit'},
    {'icon': Icons.campaign, 'label': 'Kampanye'},
    {'icon': Icons.people, 'label': 'Komunitas'},
  ];

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double cardWidth = screenWidth * 0.6;

    return Scaffold(
      appBar: AppBar(
        title: Text('Altruh'),
        backgroundColor: Colors.amber[700],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Carousel
            carousel.CarouselSlider(
              options: carousel.CarouselOptions(
                height: 200,
                autoPlay: true,
                enlargeCenterPage: true,
                viewportFraction: 0.9,
              ),
              items: carouselImages.map((url) {
                return Container(
                  margin: EdgeInsets.all(5),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.network(
                      url,
                      fit: BoxFit.cover,
                      width: 1000,
                      errorBuilder: (context, error, stackTrace) => Container(
                        color: Colors.grey,
                        child: Icon(Icons.error),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),

            // Horizontal Menu
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: SizedBox(
                height: 90, // Sesuaikan tinggi container
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  itemCount: menuItems.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        switch (index) {
                          case 0:
                            Navigator.push(context, MaterialPageRoute(
                                builder: (_) => DonasiUangPage()));
                            break;
                          case 1:
                            Navigator.push(context, MaterialPageRoute(
                                builder: (_) => DonasiBarangPage()));
                            break;
                          case 2:
                            Navigator.push(context, MaterialPageRoute(
                                builder: (_) => RiwayatPage()));
                            break;
                          // Tambahkan case untuk menu baru
                        }
                      },
                      child: Container(
                        width: 80, // Lebar setiap item menu
                        margin: EdgeInsets.symmetric(horizontal: 6),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.amber[100],
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                menuItems[index]['icon'],
                                color: Colors.amber[700],
                                size: 30,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              menuItems[index]['label'],
                              style: TextStyle(fontSize: 12),
                              textAlign: TextAlign.center,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

            // Title Kampanye
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Kampanye Terbaru',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            // Campaign Cards
            Container(
              height: 350,
              margin: EdgeInsets.only(bottom: 100),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.symmetric(horizontal: 8),
                itemCount: dummyCampaigns.length,
                itemBuilder: (context, index) {
                  return Container(
                    width: cardWidth,
                    margin: EdgeInsets.symmetric(horizontal: 4),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CampaignDetailPage(campaign: dummyCampaigns[index]),
                          ),
                        );
                      },
                      child: CampaignCard(campaign: dummyCampaigns[index]),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
