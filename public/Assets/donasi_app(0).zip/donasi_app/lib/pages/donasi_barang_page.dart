import 'package:flutter/material.dart';

class DonasiBarangPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Donasi Barang")),
      body: Center(child: Text("Halaman Donasi Barang")),
    );
  }
}
