import 'package:flutter/material.dart';

class DonasiUangPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Donasi Uang")),
      body: Center(child: Text("Halaman Donasi Uang")),
    );
  }
}
