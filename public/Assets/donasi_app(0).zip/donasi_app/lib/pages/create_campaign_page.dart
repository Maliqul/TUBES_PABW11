import 'package:flutter/material.dart';

class CreateCampaignPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Form Galang Bantuan', style: TextStyle(fontSize: 24)),
    );
  }
}
